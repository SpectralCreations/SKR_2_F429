#
# mks_robin_e3.py
#
import robin
robin.prepare("0x08005000", "mks_robin_e3.ld", "Robin_e3.bin")
